﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HomeWork_1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button1_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            int r = Random.Shared.Next(0, 256);
            int g = Random.Shared.Next(0, 256);
            int b = Random.Shared.Next(0, 256);

            SolidColorBrush solidColor = new SolidColorBrush(Color.FromRgb((byte)r, (byte)g, (byte)b));
            Button1.Background = solidColor;

            MessageBox.Show($"BackGroundColor is {solidColor.Color}");
        }

        private void Button2_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            int r = Random.Shared.Next(0, 256);
            int g = Random.Shared.Next(0, 256);
            int b = Random.Shared.Next(0, 256);

            SolidColorBrush solidColor = new SolidColorBrush(Color.FromRgb((byte)r, (byte)g, (byte)b));
            Button2.Background = solidColor;

            MessageBox.Show($"BackGroundColor is {solidColor.Color}");
        }

        private void Button3_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            int r = Random.Shared.Next(0, 256);
            int g = Random.Shared.Next(0, 256);
            int b = Random.Shared.Next(0, 256);

            SolidColorBrush solidColor = new SolidColorBrush(Color.FromRgb((byte)r, (byte)g, (byte)b));
            Button3.Background = solidColor;

            MessageBox.Show($"BackGroundColor is {solidColor.Color}");
        }

        private void Button4_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            int r = Random.Shared.Next(0, 256);
            int g = Random.Shared.Next(0, 256);
            int b = Random.Shared.Next(0, 256);

            SolidColorBrush solidColor = new SolidColorBrush(Color.FromRgb((byte)r, (byte)g, (byte)b));
            Button4.Background = solidColor;

            MessageBox.Show($"BackGroundColor is {solidColor.Color}");
        }

        private void Button5_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            int r = Random.Shared.Next(0, 256);
            int g = Random.Shared.Next(0, 256);
            int b = Random.Shared.Next(0, 256);

            SolidColorBrush solidColor = new SolidColorBrush(Color.FromRgb((byte)r, (byte)g, (byte)b));
            Button5.Background = solidColor;

            MessageBox.Show($"BackGroundColor is {solidColor.Color}");
        }

        private void Button6_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            int r = Random.Shared.Next(0, 256);
            int g = Random.Shared.Next(0, 256);
            int b = Random.Shared.Next(0, 256);

            SolidColorBrush solidColor = new SolidColorBrush(Color.FromRgb((byte)r, (byte)g, (byte)b));
            Button6.Background = solidColor;

            MessageBox.Show($"BackGroundColor is {solidColor.Color}");
        }
        private void Button1_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            Button1.Visibility = Visibility.Hidden;
        }

        private void Button2_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            Button2.Visibility = Visibility.Hidden;
        }

        private void Button3_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            Button3.Visibility = Visibility.Hidden;
        }

        private void Button4_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            Button4.Visibility = Visibility.Hidden;
        }

        private void Button5_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            Button5.Visibility = Visibility.Hidden;
        }

        private void Button6_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            Button6.Visibility = Visibility.Hidden;
        }
    }
}
